

<?php
// Disable caching.
header('Cache-Control: no-cache, no-store, must-revalidate');
header('Pragma: no-cache');
header('Expires: 0');
if (isset($_POST['t'])) {
    // Update file.
    file_put_contents('docs/note.txt', $_POST['t']);
    die();
}
if (strpos($_SERVER['HTTP_USER_AGENT'], 'curl') === 0) 
{
    // Output raw file if client is curl.
    print file_get_contents($path);
    die();
}
?>



<?php
 // echo "The time is " . date("h:i:sa") . " and today is " . date("Y/m/d") . "<br>"; 
 // echo 'http://' . $_SERVER['HTTP_HOST'] . $_SERVER['REQUEST_URI']; 
    $targetfile = 'docs/out.txt';
    $fpread = fopen( 'docs/note.txt' , "rb");
    $fpout = fopen( $targetfile, "wb" );
        while(!feof($fpread)) 
	{
           fputs( $fpout , fread( $fpread , 1024 * 8 ), 1024 * 8 ) ;
           fputs( $fpout , "\n" );
	}
    fclose( $fpout );
    fclose( $fpread );
?>



<!DOCTYPE html>
<html>
<head>
    <title>Web Notepad PHP</title>
    <meta charset="utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <link rel="shortcut icon" href="favicon.ico" />
    <link href="styles.css" rel="stylesheet" />
</head>


<body>







    <div class="container">
<?php
//  This is a comment:
//  Tiny PHP code for a notepad for education purpose and students (*easily hackable, no warranty!*) 
include('menu.html'); 
?>

      <textarea id="content"><?php if (file_exists('docs/note.txt')) { print htmlspecialchars(file_get_contents('docs/note.txt'), ENT_QUOTES, 'UTF-8'); } ?></textarea>
    <pre id="printable"></pre>
    </div>
    <script src="script.js"></script>
</body>
</html>




